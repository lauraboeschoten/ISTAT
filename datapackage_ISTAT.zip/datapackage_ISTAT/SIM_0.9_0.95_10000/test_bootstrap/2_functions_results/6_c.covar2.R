c.covar2 <- function(impdats, nboot){
  
  MCimp <- matrix(NA, nboot,12)
  Ubar    <- matrix(NA, 1,6)
  Between <- matrix(NA, 1,6)
  
  
  for(b in 1:nboot){
    
    sub <- ICCres <- ESS <- NULL
    sub[[1]] <- impdats[[b]][which(as.numeric(substring(impdats[[b]]$Q2,1,1))==1),]
    sub[[2]] <- impdats[[b]][which(as.numeric(substring(impdats[[b]]$Q2,1,1))==2),]
    sub[[3]] <- impdats[[b]][which(as.numeric(substring(impdats[[b]]$Q2,1,1))==3),]
    
    for(k in 1:3){
      subsub1 <- as.numeric(substring(sub[[k]]$L.C,1,1))
      subsub2 <- as.numeric(substring(sub[[k]]$L.C,3,3))
      subsub3 <- as.numeric(substring(sub[[k]]$L.C,5,5))
      subbers1 <- c(subsub1, subsub2, subsub3)
      subind1 <- rep(1:nrow(sub[[k]]), 3)
      subfin1 <- cbind(subind1, subbers1)
      subfin1 <- as.data.frame(subfin1)
      ICCres[k] <- ICCbare(subind1, subbers1, subfin1)
      ESS[k] <-  (nrow(sub[[k]])*3)/(1+((3-1)*ICCres[k]))
      
      
      MCimp[b,c((k-1+(k*1)):(k+(k*1)))] <- c(table(substring(impdats[[b]]$Q2,1,1), substring(impdats[[b]]$L.C,1,1))[k,]+
                                               table(substring(impdats[[b]]$Q2,3,3), substring(impdats[[b]]$L.C,3,3))[k,]+
                                               table(substring(impdats[[b]]$Q2,5,5), substring(impdats[[b]]$L.C,5,5))[k,])/
        sum(table(substring(impdats[[b]]$Q2,1,1), substring(impdats[[b]]$L.C,1,1))[k,]+
              table(substring(impdats[[b]]$Q2,3,3), substring(impdats[[b]]$L.C,3,3))[k,]+
              table(substring(impdats[[b]]$Q2,5,5), substring(impdats[[b]]$L.C,5,5))[k,])
      MCimp[b,c((k+5+(k*1)):(k+6+(k*1)))] <- MCimp[b,c((k-1+(k*1)):(k+(k*1)))]*
        (1-MCimp[b,c((k-1+(k*1)):(k+(k*1)))])/ESS[k]
    }
  }
  
  # pool them
  for(j in 1:6){
    totalres[[6]][i,j] <- mean(MCimp[,j])
    Ubar[,j]     <- mean(MCimp[,j+6])
    Between[,j]  <- var(MCimp[,j])
    totalres[[6]][i,j+6] <- Ubar[,j]+(nboot+1)*(Between[,j]/nboot) 
  }
  return(totalres[[6]])
}

