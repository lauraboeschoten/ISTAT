setwd("C:\\Users\\lboescho\\surfdrive\\ISTAT\\NA_ISTAT\\SIM\\test_bootstrap")

load("impdats.Rdata")


library(boot)

dat <- impdats[[5]]
d <- dat

rsq <- function(dat, indices) {
  d <- dat[indices,] # allows boot to select sample 
  a <-  table(substring(d$Q1,1,1), substring(d$L.C,1,1))+
        table(substring(d$Q1,3,3), substring(d$L.C,3,3))+
        table(substring(d$Q1,5,5), substring(d$L.C,5,5))
  for(i in 1:nrow(a)){
    a[i,] <- a[i,]/sum(a[i,])
  }
  return(a,b)
} 
# bootstrapping with 1000 replications 
results <- boot(dat=dat, statistic=rsq, 
                R=10000)
results


###
dat <- impdats[[5]]
# function to obtain R-Squared from the data 
rsq <- function(dat, indices) {
  d <- dat[indices,] # allows boot to select sample 
  a <-  table(substring(d$L.C,1,1))+
    table(substring(d$L.C,3,3))+
    table(substring(d$L.C,5,5))
  a <- a/sum(a)
  return(a)
} 
# bootstrapping with 1000 replications 
results <- boot(dat=dat, statistic=rsq, 
                R=10000)
results

###

rsq <- function(dat, indices) {
  d <- dat[indices,] # allows boot to select sample 
  a <-  (table(substring(d$Q2,1,1), substring(d$L.C,1,1))+
    table(substring(d$Q2,3,3), substring(d$L.C,3,3))+
    table(substring(d$Q2,5,5), substring(d$L.C,5,5)))[1,]
    a <- a/sum(a)

  return(a)
} 
# bootstrapping with 1000 replications 
results <- boot(dat=dat, statistic=rsq, 
                R=1000)
results



