setwd("C:\\Users\\lboescho\\surfdrive\\ISTAT\\NA_ISTAT\\SIM\\test_bootstrap")

load("impdats.Rdata")


library(boot)

d <- impdats[[5]]

a <-  table(substring(d$Q1,1,1), substring(d$L.C,1,1))+
  table(substring(d$Q1,3,3), substring(d$L.C,3,3))+
  table(substring(d$Q1,5,5), substring(d$L.C,5,5))

chisq.test(a) 


a <-  table(substring(d$Q2,1,1), substring(d$L.C,1,1))+
  table(substring(d$Q2,3,3), substring(d$L.C,3,3))+
  table(substring(d$Q2,5,5), substring(d$L.C,5,5))

chisq.test(a) 

#
a <- table(substring(d$Q1,1,1), substring(d$L.C,1,1))
b <- table(substring(d$Q1,3,3), substring(d$L.C,3,3))
c <- table(substring(d$Q1,5,5), substring(d$L.C,5,5))


e <- cbind(as.vector(a),as.vector(b),as.vector(c))
chisq.test(e) 

#
a <- table(substring(d$Q2,1,1), substring(d$L.C,1,1))
b <- table(substring(d$Q2,3,3), substring(d$L.C,3,3))
c <- table(substring(d$Q2,5,5), substring(d$L.C,5,5))


e <- cbind(as.vector(a),as.vector(b),as.vector(c))
chisq.test(e) 

#
a <- table(substring(d$L.C,1,1))
b <- table(substring(d$L.C,3,3))
c <- table(substring(d$L.C,5,5))


e <- cbind(as.vector(a),as.vector(b),as.vector(c))
chisq.test(e) 


#

a <-  table(substring(d$Q1,1,1), substring(d$L.C,1,1))+
  table(substring(d$Q1,3,3), substring(d$L.C,3,3))+
  table(substring(d$Q1,5,5), substring(d$L.C,5,5))


a <- table(d$Q2, d$L.C)

chisq.test(a) 


