create_storage <- function(nsim){
  
  res1  <- matrix(NA, nsim, 6) # mixture
  colnames(res1) <- c("X1","X2","X3","SE1","SE2","SE3")
  
  res2  <- matrix(NA, nsim, 4) # markov 
  colnames(res2) <- c("L1","L2","SE1","SE2")
  
  res3 <- matrix(NA, nsim, 12) # markov 
  colnames(res3) <- c("Q1L1","Q1L2",
                      "Q2L1","Q2L2",
                      "Q3L1","Q3L2",
                      "SE1","SE2",
                      "SE3","SE4",
                      "SE5","SE6")
  
  res4 <- matrix(NA, nsim, 12) # markov 
  colnames(res4) <- c("Q1L1","Q1L2",
                      "Q2L1","Q2L2",
                      "Q3L1","Q3L2",
                      "SE1","SE2",
                      "SE3","SE4",
                      "SE5","SE6")
  

  MCtotalres <- list(res1, res2, res3, res4)
  return(MCtotalres)
}