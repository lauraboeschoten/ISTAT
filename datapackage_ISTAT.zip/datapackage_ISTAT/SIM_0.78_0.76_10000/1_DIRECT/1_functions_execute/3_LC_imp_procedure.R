LC_imp_procedure <- function(nsim, ssize, timesize, i) {
  
    # run the LC model
    envir       <- new.env()
    template_LC(
      envir              = envir,
      i                  = i,
      temp.filename.base = paste0("model")
    )
    
}