covar1 <- function(scan.mod){
  
  #Find row where only appearance of Profile appears in the data
  lin.prof  <- grep('ProbMeans-Model',scan.mod)[1]
  
  totalres[[3]][i,] <- c(strsplit(scan.mod[lin.prof+5], "\t")[[1]][c(8,10)],
                         strsplit(scan.mod[lin.prof+6], "\t")[[1]][c(8,10)],
                         strsplit(scan.mod[lin.prof+7], "\t")[[1]][c(8,10)],
                         strsplit(scan.mod[lin.prof+5], "\t")[[1]][c(9,11)],
                         strsplit(scan.mod[lin.prof+6], "\t")[[1]][c(9,11)],
                         strsplit(scan.mod[lin.prof+7], "\t")[[1]][c(9,11)])
  
  return(totalres[[3]])
  
}