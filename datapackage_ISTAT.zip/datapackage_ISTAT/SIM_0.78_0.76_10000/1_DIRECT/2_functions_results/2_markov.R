markov <- function(scan.mod){
  
  #Find row where only appearance of Profile appears in the data
  lin.prof  <- grep('Profile',scan.mod)[1]
  
  totalres[[2]][i,] <- strsplit(scan.mod[lin.prof+3], "\t")[[1]][c(8,10,9,11)]
  
  return(totalres[[2]])
  
}