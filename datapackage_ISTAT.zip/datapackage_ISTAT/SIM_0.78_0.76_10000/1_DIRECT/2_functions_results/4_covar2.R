covar2 <- function(scan.mod){
  
  #Find row where only appearance of Profile appears in the data
  lin.prof  <- grep('ProbMeans-Model',scan.mod)[1]
  
  totalres[[4]][i,] <- c(strsplit(scan.mod[lin.prof+9], "\t")[[1]][c(8,10)],
                         strsplit(scan.mod[lin.prof+10], "\t")[[1]][c(8,10)],
                         strsplit(scan.mod[lin.prof+11], "\t")[[1]][c(8,10)],
                         strsplit(scan.mod[lin.prof+9], "\t")[[1]][c(9,11)],
                         strsplit(scan.mod[lin.prof+10], "\t")[[1]][c(9,11)],
                         strsplit(scan.mod[lin.prof+11], "\t")[[1]][c(9,11)])
  
  return(totalres[[4]])
  
}