setwd("C:/Users/lboescho/surfdrive/ISTAT/NA_ISTAT/SIM_0.78_0.76_10000/6_MI_B10")

options(scipen = 999)

#load packages
library(brew)
library(mefa)
library(plyr)
library(ICC)

#global parameters
nsim     <- 1
ssize    <- 10000
timesize <- 3
nboot    <- 10

# space to save output
sets    <- vector("list", nsim)
impdats <- vector("list", 5)

# load functions
source("1_functions_execute/1_create_storage.R")
source("1_functions_execute/2_aggregate.R")
source("1_functions_execute/3_LC_imp_procedure.R")
source("1_functions_execute/4_LG_template.R")

source("2_functions_results/1_mixture.R")
source("2_functions_results/2_c.markov.R")
source("2_functions_results/3_m.markov.R")
source("2_functions_results/4_c.covar1.R")
source("2_functions_results/5_m.covar1.R")
source("2_functions_results/6_c.covar2.R")
source("2_functions_results/7_m.covar2.R")

totalres <- create_storage(nsim)

# read in simulated data
simdat <- read.delim("C:/Users/lboescho/surfdrive/ISTAT/NA_ISTAT/SIM_0.78_0.76_10000/simsets.txt", header = T) 

# start the simulation
for (i in 1:nsim) {
  
  begin <- Sys.time()
  cat(i)
  set.seed(i)
  
  # bootstrapping procedure
  longboots <- aggregate_procedure(simdat, i, timesize, ssize)
  write.table(longboots, paste0("longboots.txt"), row.names = F, quote = F)

  # Run LC models on the bootstraps and create imputations for them
  impdats <- LC_imp_procedure(nsim, ssize, timesize, i, nboot)
  
  totalres[[1]]  <- mixture(impdats, nboot)
  totalres[[2]]  <- c.markov(impdats, nboot)
  totalres[[3]]  <- m.markov(impdats, nboot)
  totalres[[4]]  <- c.covar1(impdats, nboot)
  totalres[[5]]  <- m.covar1(impdats, nboot)
  totalres[[6]]  <- c.covar2(impdats, nboot)
  totalres[[7]]  <- m.covar2(impdats, nboot)
  
  write.table(totalres[[1]],"totalres1.txt",row.names = F,quote = F)
  write.table(totalres[[2]],"totalres2.txt",row.names = F,quote = F)
  write.table(totalres[[3]],"totalres3.txt",row.names = F,quote = F)
  write.table(totalres[[4]],"totalres4.txt",row.names = F,quote = F)
  write.table(totalres[[5]],"totalres5.txt",row.names = F,quote = F)
  write.table(totalres[[6]],"totalres6.txt",row.names = F,quote = F)
  write.table(totalres[[7]],"totalres7.txt",row.names = F,quote = F)
      
  end <- Sys.time()
  print(end-begin)
}
