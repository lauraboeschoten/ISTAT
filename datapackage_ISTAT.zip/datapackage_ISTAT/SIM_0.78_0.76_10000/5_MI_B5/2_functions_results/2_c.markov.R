c.markov <- function(impdats, nboot){
  
  MCimp <- matrix(NA, nboot,4)
  Ubar    <- matrix(NA, 1,2)
  Between <- matrix(NA, 1,2)
  
  
  for(b in 1:nboot){
  
  MCimp[b,1:2] <- c(table(substring(impdats[[b]]$L.C,1,1))+
                    table(substring(impdats[[b]]$L.C,3,3))+
                    table(substring(impdats[[b]]$L.C,5,5)))/
                sum(table(substring(impdats[[b]]$L.C,1,1))+
                    table(substring(impdats[[b]]$L.C,3,3))+
                    table(substring(impdats[[b]]$L.C,5,5)))
  MCimp[b,3:4] <- MCimp[b,1:2]*
    (1-MCimp[b,1:2])/sum(table(substring(impdats[[b]]$L.C,1,1))+
                         table(substring(impdats[[b]]$L.C,3,3))+
                         table(substring(impdats[[b]]$L.C,5,5)))
  }
  
  # pool them
  for(j in 1:2){
    totalres[[2]][i,j] <- mean(MCimp[,j])
    Ubar[,j]     <- mean(MCimp[,j+2])
    Between[,j]  <- var(MCimp[,j])
    totalres[[2]][i,j+2] <- Ubar[,j]+(nboot+1)*(Between[,j]/nboot) 
  }
  return(totalres[[2]])
}

  