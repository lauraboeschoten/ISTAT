mixture <- function(impdats, nboot){
  
  miximp   <- matrix(NA, 5,6)
  Ubar    <- matrix(NA, 1,3)
  Between <- matrix(NA, 1,3)
  
  # create proportions and variances 
  for(b in 1:nboot){
    miximp[b,1:3] <- table(substring(impdats[[b]]$X,1,1))/sum(table(substring(impdats[[b]]$X,1,1)))
    miximp[b,4:6] <- miximp[b,1:3]*(1-miximp[b,1:3])/sum(table(substring(impdats[[b]]$X,1,1)))
  }
  
  # pool them
  for(j in 1:3){
    totalres[[1]][i,j] <- mean(miximp[,j])
    Ubar[,j]     <- mean(miximp[,j+3])
    Between[,j]  <- var(miximp[,j])
    totalres[[1]][i,j+3] <- Ubar[,j]+(nboot+1)*(Between[,j]/nboot) 
    
  }
  return(totalres[[1]])
}