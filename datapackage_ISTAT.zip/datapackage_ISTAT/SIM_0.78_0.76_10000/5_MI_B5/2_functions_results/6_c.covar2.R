c.covar2 <- function(impdats, nboot){
  
  MCimp <- matrix(NA, nboot,12)
  Ubar    <- matrix(NA, 1,6)
  Between <- matrix(NA, 1,6)
  
  
  for(b in 1:nboot){
      
    for(k in 1:3){
      
      MCimp[b,c((k-1+(k*1)):
                  (k+(k*1)))] <- c(table(substring(impdats[[b]]$Q2,1,1), substring(impdats[[b]]$L.C,1,1))[k,]+
                                   table(substring(impdats[[b]]$Q2,3,3), substring(impdats[[b]]$L.C,3,3))[k,]+
                                   table(substring(impdats[[b]]$Q2,5,5), substring(impdats[[b]]$L.C,5,5))[k,])/
                               sum(table(substring(impdats[[b]]$Q2,1,1), substring(impdats[[b]]$L.C,1,1))[k,]+
                                   table(substring(impdats[[b]]$Q2,3,3), substring(impdats[[b]]$L.C,3,3))[k,]+
                                   table(substring(impdats[[b]]$Q2,5,5), substring(impdats[[b]]$L.C,5,5))[k,])
      MCimp[b,c((k+5+(k*1)):(k+6+(k*1)))] <- MCimp[b,c((k-1+(k*1)):(k+(k*1)))]*
        (1-MCimp[b,c((k-1+(k*1)):
                       (k+(k*1)))])/sum(table(substring(impdats[[b]]$Q2,1,1), substring(impdats[[b]]$L.C,1,1))[k,]+
                                        table(substring(impdats[[b]]$Q2,3,3), substring(impdats[[b]]$L.C,3,3))[k,]+
                                        table(substring(impdats[[b]]$Q2,5,5), substring(impdats[[b]]$L.C,5,5))[k,])
    }
      
  }
  
  # pool them
  for(j in 1:6){
    totalres[[6]][i,j] <- mean(MCimp[,j])
    Ubar[,j]     <- mean(MCimp[,j+6])
    Between[,j]  <- var(MCimp[,j])
    totalres[[6]][i,j+6] <- Ubar[,j]+(nboot+1)*(Between[,j]/nboot) 
  }
  return(totalres[[6]])
}

