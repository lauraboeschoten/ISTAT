template_LC <- function(envir, i, b, temp.filename.base) {
  
  temp.filename <- paste(temp.filename.base, ".lgs", sep="")                        
  template      <- file("syntax.brew", 'r')
  brew(template, output=temp.filename) 
  close(template)
  shell(sprintf('"C:\\Users\\lboescho\\LatentGOLD5.1\\lg51.exe" %s /b /l', temp.filename))
  #shell(sprintf('"C:\\Users\\lboescho\\LatentGOLD5.0\\lg50.exe" %s', temp.filename))
  #shell(sprintf('"C:\\Users\\Documents\\LatentGOLD5.1\\lg51.exe" %s /b /l', temp.filename))
  }


