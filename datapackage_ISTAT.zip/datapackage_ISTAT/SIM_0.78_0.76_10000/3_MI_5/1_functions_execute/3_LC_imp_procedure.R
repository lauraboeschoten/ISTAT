LC_imp_procedure <- function(nsim, ssize, timesize, i, nboot) {
  
  # run the LC model
  envir       <- new.env()
  template_LC(
    envir              = envir,
    i                  = i,
    temp.filename.base = paste0("model")
  )
  
  post  <- as.data.frame(read.delim("posteriors.dat", header = T, sep = "\t"))
  
  # for every bootstrap sample
  for (b in 1:nboot) {
    impdata <- NULL
    
    # for every profile in the original data
    for (m in 1:(nrow(post)/timesize)) {
      
      # create subset of the profile
      subpost     <- NULL
      subpost     <- subset(post, caseID == m)
      longsubpost <- rep(subpost, subpost[1, "V1"])
      longsubpost$timenr  <- rep(1:timesize, (nrow(longsubpost)/timesize))
      
      # turn posteriors into numeric variables
      cols <- c(12:37)
      longsubpost[, cols] <- apply(longsubpost[, cols], 2, function(x) as.numeric(as.character(x)))
      
      # create empty variables to store imputations
      longsubpost[, c("X", "L.C", "L.M")] <- NA
      
      # if statement for if the profile was not in the bootstrap
      if (longsubpost[1, "V1"] > 0) {
        
        for (j in 1:nrow(longsubpost)) {
          
          # imputation for X and markov on timepoint 1
          if (longsubpost[j, "timenr"] == 1) {
            longsubpost[j, c("X")] <- sample(1:3, 1, longsubpost[j, c("X.1", "X.2", "X.3")], replace = T)
            
            # imputation for markov conditional on imputation of X
            if (longsubpost[j, "X"] == "1") {
              longsubpost[j, "L.C"] <- (runif(1) < longsubpost[j, "jf4_1_2"]) + 1
            } else if (longsubpost[j, "X"] == "2") {
              longsubpost[j, "L.C"] <- (runif(1) < longsubpost[j, "jf4_2_2"]) + 1
            } else if (longsubpost[j, "X"] == "3") {
              longsubpost[j, "L.C"] <- (runif(1) < longsubpost[j, "jf4_3_2"]) + 1
            }
          }
          
          # imputation for other timepoints
          else {
            longsubpost[j, c("X")] <- longsubpost[j - 1, c("X")]
            if (longsubpost[j - 1, "X"] == "1" & longsubpost[j - 1, "L.C"] == "1") {
              longsubpost[j, "L.C"] <- (runif(1) < longsubpost[j, "jf5_1_1_2"]) + 1}
            else if (longsubpost[j - 1, "X"] == "1" & longsubpost[j - 1, "L.C"] == "2") {
              longsubpost[j, "L.C"] <- (runif(1) < longsubpost[j, "jf5_1_2_2"]) + 1}
            else if (longsubpost[j - 1, "X"] == "2" & longsubpost[j - 1, "L.C"] == "1") {
              longsubpost[j, "L.C"] <- (runif(1) < longsubpost[j, "jf5_2_1_2"]) + 1}
            else if (longsubpost[j - 1, "X"] == "2" & longsubpost[j - 1, "L.C"] == "2") {
              longsubpost[j, "L.C"] <- (runif(1) < longsubpost[j, "jf5_2_2_2"]) + 1}
            else if (longsubpost[j - 1, "X"] == "3" & longsubpost[j - 1, "L.C"] == "1") {
              longsubpost[j, "L.C"] <- (runif(1) < longsubpost[j, "jf5_3_1_2"]) + 1}
            else if (longsubpost[j - 1, "X"] == "3" & longsubpost[j - 1, "L.C"] == "2") {
              longsubpost[j, "L.C"] <- (runif(1) < longsubpost[j, "jf5_3_2_2"]) + 1}
          }
        }
        
        longsubpost[, "X"] <- as.factor(longsubpost[, "X"])
        
        # impute timepoints 1 to 12 of L marginal
        longsubpost[, "L.M"] <- (rbinom(nrow(longsubpost), 1, longsubpost[, "MCX.2"])) + 1
        
        # create a short dataset with 1 row per person
        short.data  <- as.data.frame(matrix(NA, nrow(longsubpost) / 5, 8))
        colnames(short.data) <- c("Y1", "Y2", "Q1", "Q2","X", "L.C", "L.M","mod")
        
        # create string variables with complete trajectories per person
        for (j in 1:nrow(longsubpost)) {
          if (longsubpost[j, "timenr"] == 1) {
            short.data[((j - 1) / timesize) + 1, 1] <- paste0(unlist(longsubpost[j, "Y1"]))
            short.data[((j - 1) / timesize) + 1, 2] <- paste0(unlist(longsubpost[j, "Y2"]))
            short.data[((j - 1) / timesize) + 1, 3] <- paste0(unlist(longsubpost[j, "Q1"]))
            short.data[((j - 1) / timesize) + 1, 4] <- paste0(unlist(longsubpost[j, "Q2"]))
            short.data[((j - 1) / timesize) + 1, 5] <- unlist(as.numeric(as.character(longsubpost[j, "X"])))
            short.data[((j - 1) / timesize) + 1, 6] <- paste0(longsubpost[(j):(j + (timesize - 1)), ("L.C")], collapse = "_")
            short.data[((j - 1) / timesize) + 1, 7] <- paste0(longsubpost[(j):(j + (timesize - 1)), ("L.M")], collapse = "_")
            short.data[((j - 1) / timesize) + 1, 8] <- paste0(unlist(longsubpost[j, "X."]))
          }
        }
        
        # if the profile is not observed in the bootstrap  
      } else {
        short.data  <- as.data.frame(matrix(NA, nrow(longsubpost) / 5, 8))
        colnames(short.data) <- c("Y1", "Y2", "Q1", "Q2","X", "L.C", "L.M","mod")
        
        for (j in 1:nrow(longsubpost)) {
          if (longsubpost[j, "timenr"] == 1) {
            short.data[((j - 1) / timesize) + 1, 1] <- paste0(unlist(longsubpost[j, "Y1"]))
            short.data[((j - 1) / timesize) + 1, 2] <- paste0(unlist(longsubpost[j, "Y2"]))
            short.data[((j - 1) / timesize) + 1, 3] <- paste0(unlist(longsubpost[j, "Q1"]))
            short.data[((j - 1) / timesize) + 1, 4] <- paste0(unlist(longsubpost[j, "Q2"]))
          }
        }
      }
      
      # combine the imputed profiles into a long dataset
      impdata <- rbind(impdata, short.data)
    }
    
    impdats[[b]] <- as.data.frame(impdata)
  }
  return(impdats)
}