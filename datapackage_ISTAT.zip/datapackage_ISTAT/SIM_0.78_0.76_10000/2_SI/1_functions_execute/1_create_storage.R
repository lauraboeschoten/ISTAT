create_storage <- function(nsim){
  
  res1  <- matrix(NA, nsim, 6) # mixture
  colnames(res1) <- c("X1","X2","X3","SE1","SE2","SE3")
  
  res2  <- matrix(NA, nsim, 4) # markov conditional
  colnames(res2) <- c("L1","L2","SE1","SE2")
  
  res3  <- matrix(NA, nsim, 4) # markov marginal
  colnames(res3) <- c("L1","L2","SE1","SE2")
  
  res4  <- matrix(NA, nsim, 12) # covar 1 conditional
  colnames(res4) <- c("L1Q1","L2Q1","L1Q2",
                      "L2Q2","L1Q3","L2Q3",
                      "SE1","SE2","SE3",
                      "SE4","SE5","SE6")
  
  res5  <- matrix(NA, nsim, 12) # covar 1 marginal
  colnames(res5) <- c("L1Q1","L2Q1","L1Q2",
                      "L2Q2","L1Q3","L2Q3",
                      "SE1","SE2","SE3",
                      "SE4","SE5","SE6")
  
  res6  <- matrix(NA, nsim, 12) # covar 2 conditional
  colnames(res6) <- c("L1Q1","L2Q1","L1Q2",
                      "L2Q2","L1Q3","L2Q3",
                      "SE1","SE2","SE3",
                      "SE4","SE5","SE6")
  
  res7  <- matrix(NA, nsim, 12) # covar 2 marginal
  colnames(res7) <- c("L1Q1","L2Q1","L1Q2",
                      "L2Q2","L1Q3","L2Q3",
                      "SE1","SE2","SE3",
                      "SE4","SE5","SE6")

  MCtotalres <- list(res1, res2, res3, res4, res5, res6, res7)
  return(MCtotalres)
}