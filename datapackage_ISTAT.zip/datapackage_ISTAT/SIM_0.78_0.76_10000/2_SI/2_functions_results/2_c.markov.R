c.markov <- function(impdats){
  
  totalres[[2]][i,1:2] <- (table(substring(impdats$L.C,1,1))+
                           table(substring(impdats$L.C,3,3))+
                           table(substring(impdats$L.C,5,5)))/(sum(table(substring(impdats$L.C,1,1)))+
                                                                 sum(table(substring(impdats$L.C,3,3)))+
                                                                 sum(table(substring(impdats$L.C,5,5))))
  totalres[[2]][i,3:4] <- totalres[[2]][i,1:2]*(1-totalres[[2]][i,1:2])/(sum(table(substring(impdats$L.C,1,1)))+
                                                                           sum(table(substring(impdats$L.C,3,3)))+
                                                                           sum(table(substring(impdats$L.C,5,5))))
  return(totalres[[2]])
}