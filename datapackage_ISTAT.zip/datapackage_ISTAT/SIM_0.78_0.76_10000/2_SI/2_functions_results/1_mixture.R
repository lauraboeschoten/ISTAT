mixture <- function(impdats){
  
  totalres[[1]][i,1:3] <- table(substring(impdats$X,1,1))/sum(table(substring(impdats$X,1,1)))
  totalres[[1]][i,4:6] <- totalres[[1]][i,1:3]*(1-totalres[[1]][i,1:3])/sum(table(substring(impdats$X,1,1)))
  
  return(totalres[[1]])
  
}