m.markov <- function(impdats){
  
  totalres[[3]][i,1:2] <- (table(substring(impdats$L.M,1,1))+
                             table(substring(impdats$L.M,3,3))+
                             table(substring(impdats$L.M,5,5)))/(sum(table(substring(impdats$L.M,1,1)))+
                                                                   sum(table(substring(impdats$L.M,3,3)))+
                                                                   sum(table(substring(impdats$L.M,5,5))))
  totalres[[3]][i,3:4] <- totalres[[3]][i,1:2]*(1-totalres[[3]][i,1:2])/(sum(table(substring(impdats$L.M,1,1)))+
                                                                           sum(table(substring(impdats$L.M,3,3)))+
                                                                           sum(table(substring(impdats$L.M,5,5))))
  return(totalres[[3]])
}