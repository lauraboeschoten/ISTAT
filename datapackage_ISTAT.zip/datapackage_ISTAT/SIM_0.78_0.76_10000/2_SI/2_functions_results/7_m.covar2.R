m.covar2 <- function(impdats, nboot){
  
  MCimp <- matrix(NA, 1,12)
  Ubar    <- matrix(NA, 1,6)
  Between <- matrix(NA, 1,6)
  
  for(k in 1:3){
    
    totalres[[7]][i,c((k-1+(k*1)):
                        (k+(k*1)))] <- c(table(substring(impdats$Q2,1,1), substring(impdats$L.M,1,1))[k,]+
                                           table(substring(impdats$Q2,3,3), substring(impdats$L.M,3,3))[k,]+
                                           table(substring(impdats$Q2,5,5), substring(impdats$L.M,5,5))[k,])/
      sum(table(substring(impdats$Q2,1,1), substring(impdats$L.M,1,1))[k,]+
            table(substring(impdats$Q2,3,3), substring(impdats$L.M,3,3))[k,]+
            table(substring(impdats$Q2,5,5), substring(impdats$L.M,5,5))[k,])
    totalres[[7]][i,c((k+5+(k*1)):(k+6+(k*1)))] <- totalres[[7]][i,c((k-1+(k*1)):(k+(k*1)))]*
      (1-totalres[[7]][i,c((k-1+(k*1)):
                             (k+(k*1)))])/sum(table(substring(impdats$Q2,1,1), substring(impdats$L.M,1,1))[k,]+
                                                table(substring(impdats$Q2,3,3), substring(impdats$L.M,3,3))[k,]+
                                                table(substring(impdats$Q2,5,5), substring(impdats$L.M,5,5))[k,])
  }
  
  return(totalres[[7]])
}

