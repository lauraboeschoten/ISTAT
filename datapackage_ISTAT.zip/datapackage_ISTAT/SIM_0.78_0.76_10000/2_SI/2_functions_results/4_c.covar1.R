c.covar1 <- function(impdats){
  
  MCimp <- matrix(NA, 1,12)
  Ubar    <- matrix(NA, 1,6)
  Between <- matrix(NA, 1,6)
  
    sub <- ICCres <- ESS <- NULL
    sub[[1]] <- impdats[which(as.numeric(substring(impdats$Q1,1,1))==1),]
    sub[[2]] <- impdats[which(as.numeric(substring(impdats$Q1,1,1))==2),]
    sub[[3]] <- impdats[which(as.numeric(substring(impdats$Q1,1,1))==3),]
    
    for(k in 1:3){
      subsub1 <- as.numeric(substring(sub[[k]]$L.C,1,1))
      subsub2 <- as.numeric(substring(sub[[k]]$L.C,3,3))
      subsub3 <- as.numeric(substring(sub[[k]]$L.C,5,5))
      subbers1 <- c(subsub1, subsub2, subsub3)
      subind1 <- rep(1:nrow(sub[[k]]), 3)
      subfin1 <- cbind(subind1, subbers1)
      subfin1 <- as.data.frame(subfin1)
      ICCres[k] <- ICCbare(subind1, subbers1, subfin1)
      ESS[k] <-  (nrow(sub[[k]])*3)/(1+((3-1)*ICCres[k]))
      
      totalres[[4]][i,c((k-1+(k*1)):(k+(k*1)))] <- c(table(substring(impdats$Q1,1,1), substring(impdats$L.C,1,1))[k,]+
                                               table(substring(impdats$Q1,3,3), substring(impdats$L.C,3,3))[k,]+
                                               table(substring(impdats$Q1,5,5), substring(impdats$L.C,5,5))[k,])/
        sum(table(substring(impdats$Q1,1,1), substring(impdats$L.C,1,1))[k,]+
              table(substring(impdats$Q1,3,3), substring(impdats$L.C,3,3))[k,]+
              table(substring(impdats$Q1,5,5), substring(impdats$L.C,5,5))[k,])
      totalres[[4]][i,c((k+5+(k*1)):(k+6+(k*1)))] <- totalres[[4]][i,c((k-1+(k*1)):(k+(k*1)))]*
        (1-totalres[[4]][i,c((k-1+(k*1)):(k+(k*1)))])/ESS[k]
    }
    

  
  return(totalres[[4]])
}

