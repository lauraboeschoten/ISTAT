setwd("C:/Users/lboescho/surfdrive/ISTAT/NA_ISTAT/SIM_0.9_0.95_10000_MCAR/1_DIRECT_2")

options(scipen = 999)

library(xtable)

#global parameters
nsim     <- 500
timesize <- 3


# ------------------------------------------------------------------------------
# 1. mixture

pop <- c(0.5800,	0.3025,	0.1175)
res <- read.delim("totalres1.txt", header=T, sep="")
bias <- matrix(NA, nsim, 3)
cov <- matrix(NA, nsim, 9)

for(i in 1:3){
  bias[,i] <- res[,i]-pop[i]
  cov[,i]  <- res[,i]-1.96*res[,i+3]
  cov[,i+3]  <- res[,i]+1.96*res[,i+3]
  cov[,i+6]  <- pop[i] > cov[,i] & pop[i] < cov[,i+3]
  
}

a <- round(colMeans(bias),4) 
b <- colSums(cov[,c(7:9)])/nsim*100 
c <- round(colMeans(cov[,c(4:6)]-cov[,c(1:3)]),4)
e <- f <- d <- NULL

for(i in 1:3){
  e[i] <- (mean(res[,i+3]))/sd(res[,i])
  f[i] <- sqrt(mean(bias[,i]^2))
}


for(i in 1:3){d <- c(d,a[i],b[i],c[i],e[i],f[i])}

d <- t(as.matrix(d))
xtable(d, digits=4)

# ------------------------------------------------------------------------------
# 2. markov

pop <- c(0.6388,	0.3612)
res <- read.delim("totalres2.txt", header=T, sep="")
res[c(82,259),] <- NA
bias <- matrix(NA, nsim, 2)
cov <- matrix(NA, nsim, 6)

for(i in 1:2){
  bias[,i] <- res[,i]-pop[i]
  cov[,i]  <- res[,i]-1.96*res[,i+2]
  cov[,i+2]  <- res[,i]+1.96*res[,i+2]
  cov[,i+4]  <- pop[i] > cov[,i] & pop[i] < cov[,i+2]
  
}

a <- round(colMeans(bias, na.rm=T),4) 
b <- (colSums(cov[,c(5:6)], na.rm=T)/(nsim-2))*100 
c <- round(colMeans(cov[,c(3:4)]-cov[,c(1:2)], na.rm=T),4)
e <- f <- d <- NULL

for(i in 1:2){
  e[i] <- (mean(res[,i+2], na.rm=T))/sd(res[,i], na.rm=T)
  f[i] <- sqrt(mean(bias[,i]^2, na.rm=T))
}



for(i in 1:2){d <- c(d,a[i],b[i],c[i],e[i],f[i])}

d <- t(as.matrix(d))
xtable(d, digits=4)
# ------------------------------------------------------------------------------
# 4. covariate 1 

pop <- c(0.9105,0.0895,0.1412,0.8588,0.5013,0.4987)	
res <- read.delim("totalres3.txt", header=T, sep="")
res[c(82,259),] <- NA
bias <- matrix(NA, nsim, 6)
cov <- matrix(NA, nsim, 18)

for(i in 1:6){
  bias[,i] <- res[,i]-pop[i]
  cov[,i]  <- res[,i]-1.96*res[,i+6]
  cov[,i+6]  <- res[,i]+1.96*res[,i+6]
  cov[,i+12]  <- pop[i] > cov[,i] & pop[i] < cov[,i+6]
  
}

a <- round(colMeans(bias, na.rm=T), 4)
b <- (colSums(cov[,c(13:18)], na.rm=T)/(nsim-2))*100
c <- round(colMeans(cov[,c(7:12)]-cov[,c(1:6)], na.rm=T),4)
d <-  matrix(NA, 2,15)
e <- f <- NULL

for(i in 1:6){
  e[i] <- (mean(res[,i+6], na.rm=T))/sd(res[,i], na.rm=T)
  f[i] <- sqrt(mean(bias[,i]^2, na.rm=T))
}


for(i in 1:2){d[i,] <- c(a[i],b[i],c[i],e[i],f[i],
                         a[i+2],b[i+2],c[i+2],e[i+2],f[i+2],
                         a[i+4],b[i+4],c[i+4],e[i+4],f[i+4])}

xtable(d, digits=4)

# ------------------------------------------------------------------------------
# 6. covariate 2 

pop <- c(0.6388, 0.3612, 0.6388, 0.3612, 0.6388, 0.3612)
res <- read.delim("totalres4.txt", header=T, sep="")
res[c(82,259),] <- NA
bias <- matrix(NA, nsim, 6)
cov <- matrix(NA, nsim, 18)

for(i in 1:6){
  bias[,i] <- res[,i]-pop[i]
  cov[,i]  <- res[,i]-1.96*res[,i+6]
  cov[,i+6]  <- res[,i]+1.96*res[,i+6]
  cov[,i+12]  <- pop[i] > cov[,i] & pop[i] < cov[,i+6]
}

a <- round(colMeans(bias, na.rm=T), 4)
b <- (colSums(cov[,c(13:18)], na.rm=T)/(nsim-2))*100
c <- round(colMeans(cov[,c(7:12)]-cov[,c(1:6)], na.rm=T),4)
d <-  matrix(NA, 2,15)
e <- f <- NULL

for(i in 1:6){
  e[i] <- (mean(res[,i+6], na.rm=T))/sd(res[,i], na.rm=T)
  f[i] <- sqrt(mean(bias[,i]^2, na.rm=T))
}


for(i in 1:2){d[i,] <- c(a[i],b[i],c[i],e[i],f[i],
                         a[i+2],b[i+2],c[i+2],e[i+2],f[i+2],
                         a[i+4],b[i+4],c[i+4],e[i+4],f[i+4])}

xtable(d, digits=4)
