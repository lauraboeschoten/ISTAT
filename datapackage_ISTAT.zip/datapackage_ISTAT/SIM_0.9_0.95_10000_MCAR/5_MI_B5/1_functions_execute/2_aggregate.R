aggregate_procedure <- function(simdat, i, timesize, ssize){
  
  # take the subset corresponding to the iteration of the simulation (i)
  tempset         <- subset(simdat, simulation_. == i)
  
  # create a timing variable
  tempset$timenr  <- rep(1:timesize, (nrow(tempset) / timesize))
  
  tempset$Q2 <- as.factor(tempset$Q2)
  tempset$timenr <- as.factor(tempset$timenr)
  
  
  for(j in 1:nrow(tempset)){
    
    if(tempset[j,"timenr"]=="3"){ tempset[j,"Y2"] <- "." }
  }
  
  
  # create storage space for short dataset
  short.temp           <- as.data.frame(matrix(NA, nrow(tempset) / timesize, 6))
  colnames(short.temp) <- c("simnr", "caseID", "Q1", "Q2", "Y1", "Y2")
  
  # create short dataset
  for (j in 1:nrow(tempset)) {
    if (tempset[j, "timenr"] == 1) {
      short.temp[((j - 1) / timesize) + 1, 1] <- unlist(tempset[j, 1])
      short.temp[((j - 1) / timesize) + 1, 2] <- unlist(tempset[j, 2])
      short.temp[((j - 1) / timesize) + 1, 3] <- paste0(tempset[(j):(j + (timesize - 1)), 3], collapse = "_")
      short.temp[((j - 1) / timesize) + 1, 4] <- paste0(tempset[(j):(j + (timesize - 1)), 4], collapse = "_")
      short.temp[((j - 1) / timesize) + 1, 5] <- paste0(tempset[(j):(j + (timesize - 1)), 5], collapse = "_")
      short.temp[((j - 1) / timesize) + 1, 6] <- paste0(tempset[(j):(j + (timesize - 1)), 6], collapse = "_")
    }
  }
  
  short.temp$misind <- NA
  
  short.temp[short.temp$Q2=="1_1_1",]$misind <- rbinom(nrow(short.temp[short.temp$Q2=="1_1_1",]), 1, 0.5) # change if MAR
  short.temp[short.temp$Q2=="2_2_2",]$misind <- rbinom(nrow(short.temp[short.temp$Q2=="2_2_2",]), 1, 0.5)
  short.temp[short.temp$Q2=="3_3_3",]$misind <- rbinom(nrow(short.temp[short.temp$Q2=="3_3_3",]), 1, 0.5)
  
  
  for(j in 1:nrow(short.temp)){
    if(short.temp[j,"misind"]=="1"){ short.temp[j,"Y2"] <- "._._." }
  }
  
  
  cols              <- c("simnr", "caseID", "Y1", "Y2", "Q1", "Q2")
  short.temp[,cols] <- lapply(short.temp[,cols], as.factor)
  
  # create aggregated dataset
  boots             <- ddply(short.temp, .(Y1, Y2, Q1, Q2), nrow)
  
  # create bootstraps 
  boots[, c("b1", "b2", "b3", "b4", "b5")] <- rmultinom(5, ssize, boots$V1/ssize)
  boots            <- as.data.frame(boots)
  
  
  # create long version of the bootstrapped data for Latent GOLD 
  longboots        <- rep(boots, each = timesize)
  longboots$timenr <- rep(1:timesize, (nrow(longboots) / timesize))
  
  for (j in 1:nrow(longboots)) {
    if (longboots[j, "timenr"] == 1) {
      longboots[j, "Y1sh"] <- substring(longboots[j, "Y1"], 1, 1)
      longboots[j, "Y2sh"] <- substring(longboots[j, "Y2"], 1, 1)
      longboots[j, "Q1sh"] <- substring(longboots[j, "Q1"], 1, 1)
      longboots[j, "Q2sh"] <- substring(longboots[j, "Q2"], 1, 1)
    }
    
    if (longboots[j, "timenr"] == 2) {
      longboots[j, "Y1sh"] <- substring(longboots[j, "Y1"], 3, 3)
      longboots[j, "Y2sh"] <- substring(longboots[j, "Y2"], 3, 3)
      longboots[j, "Q1sh"] <- substring(longboots[j, "Q1"], 3, 3)
      longboots[j, "Q2sh"] <- substring(longboots[j, "Q2"], 3, 3)
    }
    
    if (longboots[j, "timenr"] == 3) {
      longboots[j, "Y1sh"] <- substring(longboots[j, "Y1"], 5, 5)
      longboots[j, "Y2sh"] <- substring(longboots[j, "Y2"], 5, 5)
      longboots[j, "Q1sh"] <- substring(longboots[j, "Q1"], 5, 5)
      longboots[j, "Q2sh"] <- substring(longboots[j, "Q2"], 5, 5)
    }
  }
  
  longboots$caseID  <- rep(1:(nrow(longboots)/timesize), each=timesize)
  
  return(longboots)
}
