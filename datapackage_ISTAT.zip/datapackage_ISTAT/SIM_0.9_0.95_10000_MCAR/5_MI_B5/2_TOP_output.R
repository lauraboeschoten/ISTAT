setwd("C:/Users/lboescho/surfdrive/ISTAT/NA_ISTAT/SIM_0.9_0.95_10000_MCAR/5_MI_B5")

options(scipen = 999)

library(xtable)

#global parameters
nsim     <- 500
timesize <- 3

# ------------------------------------------------------------------------------
# 1. mixture
pop <- c(0.5800,	0.3025,	0.1175)
res <- read.delim("totalres1.txt", header=T, sep="")
bias <- matrix(NA, nsim, 3)
cov <- matrix(NA, nsim, 9)

for(i in 1:3){
  bias[,i]   <- res[,i]-pop[i]
  cov[,i]    <- res[,i]-1.96*sqrt(res[,i+3])
  cov[,i+3]  <- res[,i]+1.96*sqrt(res[,i+3])
  cov[,i+6]  <- pop[i] > cov[,i] & pop[i] < cov[,i+3]
}

a <- round(colMeans(bias),4) 
b <- colSums(cov[,c(7:9)])/nsim*100 
c <- round(colMeans(cov[,c(4:6)]-cov[,c(1:3)]),4)
e <- f <- d <- NULL

for(i in 1:3){
  e[i] <- sqrt(mean(res[,i+3]))/sd(res[,i])
  f[i] <- sqrt(abs(mean(bias[,i])))
}


for(i in 1:3){d <- c(d,a[i],b[i],c[i],e[i],f[i])}

d <- t(as.matrix(d))
xtable(d, digits=4)

# ------------------------------------------------------------------------------
# 2. markov conditional

pop <- c(0.6388,	0.3612)
res <- read.delim("totalres2.txt", header=T, sep="")
bias <- matrix(NA, nsim, 2)
cov <- matrix(NA, nsim, 6)

for(i in 1:2){
  bias[,i]   <- res[,i]-pop[i]
  cov[,i]    <- res[,i]-1.96*sqrt(res[,i+2])
  cov[,i+2]  <- res[,i]+1.96*sqrt(res[,i+2])
  cov[,i+4]  <- pop[i] > cov[,i] & pop[i] < cov[,i+2]
}

a <- round(colMeans(bias),4) 
b <- (colSums(cov[,c(5:6)])/nsim)*100 
c <- round(colMeans(cov[,c(3:4)]-cov[,c(1:2)]),4)
e <- f <- d <- NULL

for(i in 1:2){
  e[i] <- sqrt(mean(res[,i+2]))/sd(res[,i])
  f[i] <- sqrt(abs(mean(bias[,i])))
}



for(i in 1:2){d <- c(d,a[i],b[i],c[i],e[i],f[i])}

d <- t(as.matrix(d))
xtable(d, digits=4)

# ------------------------------------------------------------------------------
# 3. markov marginal

pop <- c(0.6388,	0.3612)
res <- read.delim("totalres3.txt", header=T, sep="")
bias <- matrix(NA, nsim, 2)
cov <- matrix(NA, nsim, 6)

for(i in 1:2){
  bias[,i] <- res[,i]-pop[i]
  cov[,i]  <- res[,i]-1.96*sqrt(res[,i+2])
  cov[,i+2]  <- res[,i]+1.96*sqrt(res[,i+2])
  cov[,i+4]  <- pop[i] > cov[,i] & pop[i] < cov[,i+2]
  
}

a <- round(colMeans(bias),4) 
b <- (colSums(cov[,c(5:6)])/nsim)*100 
c <- round(colMeans(cov[,c(3:4)]-cov[,c(1:2)]),4)
e <- f <- d <- NULL

for(i in 1:2){
  e[i] <- sqrt(mean(res[,i+2]))/sd(res[,i])
  f[i] <- sqrt(abs(mean(bias[,i])))
}



for(i in 1:2){d <- c(d,a[i],b[i],c[i],e[i],f[i])}

d <- t(as.matrix(d))
xtable(d, digits=4)

# ------------------------------------------------------------------------------
# 4. covariate 1 conditional

pop <- c(0.9105,0.0895,0.1412,0.8588,0.5013,0.4987)	
res <- read.delim("totalres4.txt", header=T, sep="")
bias <- matrix(NA, nsim, 6)
cov <- matrix(NA, nsim, 18)

for(i in 1:6){
  bias[,i] <- res[,i]-pop[i]
  cov[,i]  <- res[,i]-1.96*sqrt(res[,i+6])
  cov[,i+6]  <- res[,i]+1.96*sqrt(res[,i+6])
  cov[,i+12]  <- pop[i] > cov[,i] & pop[i] < cov[,i+6]
  
}

a <- round(colMeans(bias), 4)
b <- (colSums(cov[,c(13:18)])/nsim)*100
c <- round(colMeans(cov[,c(7:12)]-cov[,c(1:6)]),4)
d <-  matrix(NA, 2,15)
e <- f <- NULL

for(i in 1:6){
  e[i] <- sqrt(mean(res[,i+6]))/sd(res[,i])
  f[i] <- sqrt(abs(mean(bias[,i])))
}


for(i in 1:2){d[i,] <- c(a[i],b[i],c[i],e[i],f[i],
                         a[i+2],b[i+2],c[i+2],e[i+2],f[i+2],
                         a[i+4],b[i+4],c[i+4],e[i+4],f[i+4])}

xtable(d, digits=4)

# ------------------------------------------------------------------------------
# 5. covariate 1 marginal

pop <- c(0.9105,0.0895,0.1412,0.8588,0.5013,0.4987)
res <- read.delim("totalres5.txt", header=T, sep="")
bias <- matrix(NA, nsim, 6)
cov <- matrix(NA, nsim, 18)

for(i in 1:6){
  bias[,i] <- res[,i]-pop[i]
  cov[,i]  <- res[,i]-1.96*sqrt(res[,i+6])
  cov[,i+6]  <- res[,i]+1.96*sqrt(res[,i+6])
  cov[,i+12]  <- pop[i] > cov[,i] & pop[i] < cov[,i+6]
}

a <- round(colMeans(bias), 4)
b <- (colSums(cov[,c(13:18)])/nsim)*100
c <- round(colMeans(cov[,c(7:12)]-cov[,c(1:6)]),4)
d <-  matrix(NA, 2,15)
e <- f <- NULL

for(i in 1:6){
  e[i] <- sqrt(mean(res[,i+6]))/sd(res[,i])
  f[i] <- sqrt(abs(mean(bias[,i])))
}


for(i in 1:2){d[i,] <- c(a[i],b[i],c[i],e[i],f[i],
                         a[i+2],b[i+2],c[i+2],e[i+2],f[i+2],
                         a[i+4],b[i+4],c[i+4],e[i+4],f[i+4])}

xtable(d, digits=4)

# ------------------------------------------------------------------------------
# 6. covariate 2 conditional

pop <- c(0.6388, 0.3612, 0.6388, 0.3612, 0.6388, 0.3612)
res <- read.delim("totalres6.txt", header=T, sep="")
bias <- matrix(NA, nsim, 6)
cov <- matrix(NA, nsim, 18)

for(i in 1:6){
  bias[,i] <- res[,i]-pop[i]
  cov[,i]  <- res[,i]-1.96*sqrt(res[,i+6])
  cov[,i+6]  <- res[,i]+1.96*sqrt(res[,i+6])
  cov[,i+12]  <- pop[i] > cov[,i] & pop[i] < cov[,i+6]
}

a <- round(colMeans(bias), 4)
b <- (colSums(cov[,c(13:18)])/nsim)*100
c <- round(colMeans(cov[,c(7:12)]-cov[,c(1:6)]),4)
d <-  matrix(NA, 2,15)
e <- f <- NULL

for(i in 1:6){
  e[i] <- sqrt(mean(res[,i+6]))/sd(res[,i])
  f[i] <- sqrt(abs(mean(bias[,i])))
}


for(i in 1:2){d[i,] <- c(a[i],b[i],c[i],e[i],f[i],
                         a[i+2],b[i+2],c[i+2],e[i+2],f[i+2],
                         a[i+4],b[i+4],c[i+4],e[i+4],f[i+4])}

xtable(d, digits=4)
# ------------------------------------------------------------------------------
# 7. covariate 2 marginal

pop <- c(0.6388, 0.3612, 0.6388, 0.3612, 0.6388, 0.3612)
res <- read.delim("totalres7.txt", header=T, sep="")
bias <- matrix(NA, nsim, 6)
cov <- matrix(NA, nsim, 18)

for(i in 1:6){
  bias[,i] <- res[,i]-pop[i]
  cov[,i]  <- res[,i]-1.96*sqrt(res[,i+6])
  cov[,i+6]  <- res[,i]+1.96*sqrt(res[,i+6])
  cov[,i+12]  <- pop[i] > cov[,i] & pop[i] < cov[,i+6]
}

a <- round(colMeans(bias), 4)
b <- (colSums(cov[,c(13:18)])/nsim)*100
c <- round(colMeans(cov[,c(7:12)]-cov[,c(1:6)]),4)
d <-  matrix(NA, 2,15)
e <- f <- NULL

for(i in 1:6){
  e[i] <- sqrt(mean(res[,i+6]))/sd(res[,i])
  f[i] <- sqrt(abs(mean(bias[,i])))
}


for(i in 1:2){d[i,] <- c(a[i],b[i],c[i],e[i],f[i],
                         a[i+2],b[i+2],c[i+2],e[i+2],f[i+2],
                         a[i+4],b[i+4],c[i+4],e[i+4],f[i+4])}

xtable(d, digits=4)

